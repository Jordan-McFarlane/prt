package MobyDickens.BookStore.Repository;

import MobyDickens.BookStore.Models.Books;
import java.util.List;


public interface BookRepository {
        List<Books> findAllBooks();

        Books addBook(Books books);

        Books findBookById(Long bookId);

        Books editBook(Long bookId, double Price, String Title);

        boolean deleteBookById(Long bookId);


}
