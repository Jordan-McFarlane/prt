package MobyDickens.BookStore.Repository.impl;

import MobyDickens.BookStore.Models.Books;
import MobyDickens.BookStore.Models.Books;
import MobyDickens.BookStore.Repository.BookRepository;
import MobyDickens.BookStore.jpa.JpaBookRepository;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import com.google.common.collect.MoreCollectors;





@Repository
public class BookRepositoryImpl implements BookRepository{


    @Autowired
    private JpaBookRepository jpaBookRepository;


    @Override
    public List<Books> findAllBooks() {


        return (List<Books>) jpaBookRepository.findAll();
    }

    @Override
    public Books addBook(Books books) {


        return jpaBookRepository.save(books);


    }

    @Override
    public Books findBookById(Long bookId) {


        Optional<Books> bookOptional = jpaBookRepository.findById(bookId);
        if (bookOptional.isPresent()) {
            return bookOptional.get();
        }
        return null;
    }

    @Override
    public Books editBook(Long bookId, double Price, String Title) {
        Books foundBook = findBookById(bookId);
        if (foundBook != null) {
            foundBook.setTitle(Title);
            foundBook.setPrice(Price);
        }


        if (foundBook == null) {
            return null;
        }
        return jpaBookRepository.save(foundBook);
    }

    @Override
    public boolean deleteBookById(Long bookId) {
        Books foundBook = findBookById(bookId);



        if (foundBook != null) {

            jpaBookRepository.deleteById(bookId);
            return true;
        }
        return false;
    }



}
