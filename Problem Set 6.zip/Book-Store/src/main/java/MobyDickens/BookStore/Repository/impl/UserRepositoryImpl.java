package MobyDickens.BookStore.Repository.impl;

import com.google.common.collect.MoreCollectors;
import MobyDickens.BookStore.Models.User;
import MobyDickens.BookStore.Repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import MobyDickens.BookStore.jpa.JpaUserRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Repository
public class UserRepositoryImpl implements UserRepository {


    @Autowired
    private JpaUserRepository jpaUserRepository;

    @Override
    public User findByUserName(String userName) {



        return jpaUserRepository.findByUsername(userName);

    }

    @Override
    public User addUser(User user) {


        return jpaUserRepository.save(user);
    }
    }
















