package MobyDickens.BookStore.Repository;
import MobyDickens.BookStore.Models.User;


public interface UserRepository  {

        User findByUserName(String userName);

        User addUser(User user);

}
