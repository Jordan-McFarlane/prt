package MobyDickens.BookStore.bootstrap;

import MobyDickens.BookStore.Models.User;
import MobyDickens.BookStore.Models.Books;
import MobyDickens.BookStore.Repository.UserRepository;
import MobyDickens.BookStore.Repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class DataBaseLoader implements ApplicationListener<ContextRefreshedEvent> {



    @Autowired
    private BookRepository bookRepository;

    @Autowired
    private UserRepository userRepository;

    public DataBaseLoader() {

    }

    @Override
    public void onApplicationEvent(ContextRefreshedEvent event) {


        Books b1 = new Books("71 uses for snails",999.99, "Cooking");
        this.bookRepository.addBook(b1);

        Books b2 = new Books("Everybody poops",999.99,"Education");
        this.bookRepository.addBook(b2);

        Books b3 = new Books("Ingredience", 999.99, "cooking" );
        this.bookRepository.addBook(b3);

        Books b4 = new Books("Love Love", 99.99,"Romance");
        this.bookRepository.addBook(b4);


        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        User user1 = new User("admin", encoder.encode("one password"), Boolean.TRUE);
        userRepository.addUser(user1);
        User user2 = new User("Toby", encoder.encode("password"), Boolean.FALSE);
        userRepository.addUser(user2);

    }







}
