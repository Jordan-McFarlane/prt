package MobyDickens.BookStore.jpa;
import MobyDickens.BookStore.Models.User;
import org.springframework.data.repository.CrudRepository;

public interface JpaUserRepository extends CrudRepository<User, Long> {
    User findByUsername(String userName);

}
