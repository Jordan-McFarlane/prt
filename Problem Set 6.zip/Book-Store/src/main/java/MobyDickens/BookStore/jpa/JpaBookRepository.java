package MobyDickens.BookStore.jpa;


import MobyDickens.BookStore.Models.Books;
import org.springframework.data.repository.CrudRepository;
public interface JpaBookRepository extends CrudRepository<Books, Long> {

}
