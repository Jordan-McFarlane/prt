package MobyDickens.BookStore.Service;
import MobyDickens.BookStore.Models.Books;

import java.util.List;

public interface BookService {
    List<Books> findAllBooks();

    Books addBook(Books books);

    List<Books> findAllFilteredBooks(String filter);

    Books findBookById(Long bookId);

    Books editBook(Long bookId, double Price, String Title);

    boolean deleteBookById(Long bookId);

}