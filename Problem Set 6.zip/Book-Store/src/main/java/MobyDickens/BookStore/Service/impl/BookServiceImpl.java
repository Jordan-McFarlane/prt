package MobyDickens.BookStore.Service.impl;
import MobyDickens.BookStore.Models.Books;
import MobyDickens.BookStore.Repository.BookRepository;
import MobyDickens.BookStore.Repository.impl.BookRepositoryImpl;
import MobyDickens.BookStore.Service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class BookServiceImpl implements BookService {

    @Autowired
    private BookRepository bookRepository;

    public BookServiceImpl() {

    }

    @Override
    public List<Books> findAllBooks() {
        return bookRepository.findAllBooks();
    }

    @Override
    public Books addBook(Books books) {


        return bookRepository.addBook(books);
    }

    @Override
    public List<Books> findAllFilteredBooks(String filter) {
        List<Books> books = bookRepository.findAllBooks();
        return books.stream()
                .filter(g -> g.getTitle().toLowerCase().contains(filter.toLowerCase()))
                .collect(Collectors.toList());
    }

    @Override
    public Books findBookById(Long bookId) {
        return bookRepository.findBookById(bookId);
    }

    @Override
    public Books editBook(Long bookId, double Price, String Title) {
        return bookRepository.editBook(bookId, Price, Title);
    }

    @Override
    public boolean deleteBookById(Long bookId) {
        return bookRepository.deleteBookById(bookId);
    }

}

