package MobyDickens.BookStore.Service.impl;

import MobyDickens.BookStore.Models.User;
import MobyDickens.BookStore.Repository.UserRepository;
import MobyDickens.BookStore.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {


    @Autowired
    private UserRepository applicationUserRepository;

    @Override
    public User findByUserName(String username) {
        return applicationUserRepository.findByUserName(username);
    }
}
