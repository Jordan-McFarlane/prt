package MobyDickens.BookStore.Service;
import MobyDickens.BookStore.Models.User;


public interface UserService {

    User findByUserName(String username);

}
