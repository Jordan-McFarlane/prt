package MobyDickens.BookStore.Controllers;

import MobyDickens.BookStore.Models.Books;
import MobyDickens.BookStore.Service.BookService;
import MobyDickens.BookStore.Service.impl.BookServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;




@Controller
public class index {



        @Autowired
        private BookService bookService;

      public index(){


      }


            @GetMapping("/")
            public String index(Model model) {

                List<Books> bookList = this.bookService.findAllBooks();
                model.addAttribute("books", bookList);
                return "index";
            }

            @PostMapping("/")
            public String searchBooks(Model model, @RequestParam("filter") String filter) {

                model.addAttribute("books", bookService.findAllFilteredBooks(filter));
                return "index";
            }


            // Add Book


            @GetMapping("/books/add")
            public String addGamePage(Model model ) {
                return "addbook";
            }

            @PostMapping("/books/add")
            public String addGameFormSubmit(Model model, @RequestParam("title") String title
                    , @RequestParam("Price") String Price) {

                Double bookPrice = 0.0;
                if (title == null || title.isEmpty()) {
                    model.addAttribute("errorMessage", "title is required");
                    return "addbook";
                } else if (Price != null) {
                    try {
                        bookPrice = Double.valueOf(Price);
                    }catch (NumberFormatException nfex) {
                        model.addAttribute("errorMessage", "Invalid book price");
                        return "addbook";
                    }
                }

                Books book = new Books(title, bookPrice, "Fanatsy");
                book = bookService.addBook(book);
                model.addAttribute("success", Boolean.TRUE);


                return "redirect:/";
            }








    }
