package MobyDickens.BookStore.Models;

import javax.persistence.*;

@Entity
public class Books {




    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "book_id_seq")
    @SequenceGenerator(name = "book_id_seq", sequenceName = "book_id_seq", allocationSize = 100)
    private Long BookId;

    private String Title;
    private String Author;
    private String Date_Published;
    private String Genre;
    private double Price;
    //Constructor


    public Books(){

    }

    public Books(String title, double price, String genre) {

        Title = title;
        Genre = genre;
        Price = price;
    }


    //Setters
    public void setBookId(Long bookId) { BookId = bookId; }
    public void setTitle(String title) { Title = title; }
    public void setAuthor(String author) { Author = author; }
    public void setDate_Published(String date_Published) { Date_Published = date_Published; }
    public void setGenre(String genre) { Genre = genre; }
    public void setPrice(double price) { Price = price; }

    //Getters
    public Long getBookId() { return BookId; }
    public String getTitle() { return Title; }
    public String getAuthor() { return Author; }
    public String getDate_Published() { return Date_Published; }
    public String getGenre() { return Genre; }
    public double getPrice() { return Price; }
}
